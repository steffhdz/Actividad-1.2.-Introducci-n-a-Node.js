// Exercise
// WRITE THE FOLLOWING USERS NAME IN A FILE AND THEN DISPLAY THEM
// const users = [
//   { name: "Kaddy" },
//   { name: "Marc" },
//   { name: "Prince" },
//   { name: "Kally" }
// ]

const fs = require('fs');
const path = require('path');

const users = [
  {name: "Kaddy"},
  {name: "Marc"},
  {name: "Prince"},
  {name: "Kally"}
]

fs.writeFile(
  path.join(__dirname, '/', 'lec.json'),
    JSON.stringify(users),
  err=> {
    if (err)
    console.log(err);
    
  else {
    console.log("se leyo correctamente");
  };
  })